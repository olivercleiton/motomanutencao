from app.utils import validate_vehicle_data

@bp.route('/vehicles', methods=['POST'])
@jwt_required()
def create_vehicle():
    try:
        user_id = get_jwt_identity()
        data = request.get_json()
        
        # Validar dados do veículo
        errors = validate_vehicle_data(data)
        if errors:
            return jsonify({'error': '; '.join(errors)}), 400
        
        vehicle = Vehicle(
            user_id=user_id,
            name=data.get('name'),
            model=data.get('model'),
            year=data.get('year'),
            plate=data.get('plate'),
            current_mileage=data.get('current_mileage', 0)
        )
        
        db.session.add(vehicle)
        db.session.commit()
        
        return jsonify({
            'id': vehicle.id,
            'name': vehicle.name,
            'model': vehicle.model,
            'year': vehicle.year,
            'plate': vehicle.plate,
            'current_mileage': vehicle.current_mileage
        }), 201
        
    except Exception as e:
        print(f"Erro ao criar veículo: {str(e)}")
        return jsonify({'error': 'Erro ao criar veículo'}), 500