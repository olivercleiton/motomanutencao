from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from flask_cors import CORS
from datetime import datetime, timedelta
import bcrypt
import os

# Configuração do app
app = Flask(__name__)
app.config['SECRET_KEY'] = 'motomanutencao-secret-key-2024'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///motomanutencao.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = 'jwt-secret-key-2024'
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(days=30)

db = SQLAlchemy(app)
jwt = JWTManager(app)
CORS(app)

# Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    vehicles = db.relationship('Vehicle', backref='owner', lazy=True, cascade='all, delete-orphan')
    
    def set_password(self, password):
        self.password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    
    def check_password(self, password):
        return bcrypt.checkpw(password.encode('utf-8'), self.password_hash.encode('utf-8'))

class Vehicle(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    model = db.Column(db.String(100), nullable=False)
    year = db.Column(db.Integer, nullable=False)
    plate = db.Column(db.String(20))
    current_mileage = db.Column(db.Float, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    services = db.relationship('Service', backref='vehicle', lazy=True, cascade='all, delete-orphan')
    maintenance_configs = db.relationship('MaintenanceConfig', backref='vehicle', lazy=True, cascade='all, delete-orphan')

class Service(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    vehicle_id = db.Column(db.Integer, db.ForeignKey('vehicle.id'), nullable=False)
    service_type = db.Column(db.String(100), nullable=False)
    date = db.Column(db.Date, nullable=False)
    mileage = db.Column(db.Float, nullable=False)
    cost = db.Column(db.Float, default=0)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class MaintenanceConfig(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    vehicle_id = db.Column(db.Integer, db.ForeignKey('vehicle.id'), nullable=False)
    service_type = db.Column(db.String(100), nullable=False)
    interval_km = db.Column(db.Float, nullable=False)
    last_service_km = db.Column(db.Float, default=0)

# Rotas de Autenticação
@app.route('/api/auth/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        
        if User.query.filter_by(email=data.get('email')).first():
            return jsonify({'error': 'Email já cadastrado'}), 400
        
        user = User(
            name=data.get('name'),
            email=data.get('email')
        )
        user.set_password(data.get('password'))
        
        db.session.add(user)
        db.session.commit()
        
        access_token = create_access_token(identity=user.id)
        return jsonify({
            'message': 'Usuário criado com sucesso',
            'access_token': access_token,
            'user': {
                'id': user.id,
                'name': user.name,
                'email': user.email
            }
        }), 201
        
    except Exception as e:
        print(f"Erro no registro: {str(e)}")
        return jsonify({'error': 'Erro ao criar usuário'}), 500

@app.route('/api/auth/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        user = User.query.filter_by(email=data.get('email')).first()
        
        if user and user.check_password(data.get('password')):
            access_token = create_access_token(identity=user.id)
            return jsonify({
                'message': 'Login realizado com sucesso',
                'access_token': access_token,
                'user': {
                    'id': user.id,
                    'name': user.name,
                    'email': user.email
                }
            })
        
        return jsonify({'error': 'Email ou senha inválidos'}), 401
        
    except Exception as e:
        print(f"Erro no login: {str(e)}")
        return jsonify({'error': 'Erro no login'}), 500

@app.route('/api/auth/me', methods=['GET'])
@jwt_required()
def get_current_user():
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        return jsonify({
            'id': user.id,
            'name': user.name,
            'email': user.email
        })
        
    except Exception as e:
        return jsonify({'error': 'Erro ao buscar usuário'}), 500

# Rotas de Veículos
@app.route('/api/vehicles', methods=['GET'])
@jwt_required()
def get_vehicles():
    try:
        user_id = get_jwt_identity()
        vehicles = Vehicle.query.filter_by(user_id=user_id).all()
        
        return jsonify([{
            'id': v.id,
            'name': v.name,
            'model': v.model,
            'year': v.year,
            'plate': v.plate,
            'current_mileage': v.current_mileage,
            'created_at': v.created_at.isoformat()
        } for v in vehicles])
        
    except Exception as e:
        print(f"Erro ao buscar veículos: {str(e)}")
        return jsonify({'error': 'Erro ao buscar veículos'}), 500

@app.route('/api/vehicles', methods=['POST'])
@jwt_required()
def create_vehicle():
    try:
        user_id = get_jwt_identity()
        data = request.get_json()
        
        vehicle = Vehicle(
            user_id=user_id,
            name=data.get('name'),
            model=data.get('model'),
            year=data.get('year'),
            plate=data.get('plate'),
            current_mileage=data.get('current_mileage', 0)
        )
        
        db.session.add(vehicle)
        db.session.commit()
        
        return jsonify({
            'id': vehicle.id,
            'name': vehicle.name,
            'model': vehicle.model,
            'year': vehicle.year,
            'plate': vehicle.plate,
            'current_mileage': vehicle.current_mileage
        }), 201
        
    except Exception as e:
        print(f"Erro ao criar veículo: {str(e)}")
        return jsonify({'error': 'Erro ao criar veículo'}), 500

@app.route('/api/vehicles/<int:vehicle_id>', methods=['PUT'])
@jwt_required()
def update_vehicle(vehicle_id):
    try:
        user_id = get_jwt_identity()
        vehicle = Vehicle.query.filter_by(id=vehicle_id, user_id=user_id).first()
        
        if not vehicle:
            return jsonify({'error': 'Veículo não encontrado'}), 404
        
        data = request.get_json()
        vehicle.name = data.get('name', vehicle.name)
        vehicle.model = data.get('model', vehicle.model)
        vehicle.year = data.get('year', vehicle.year)
        vehicle.plate = data.get('plate', vehicle.plate)
        vehicle.current_mileage = data.get('current_mileage', vehicle.current_mileage)
        
        db.session.commit()
        
        return jsonify({
            'id': vehicle.id,
            'name': vehicle.name,
            'model': vehicle.model,
            'year': vehicle.year,
            'plate': vehicle.plate,
            'current_mileage': vehicle.current_mileage
        })
        
    except Exception as e:
        print(f"Erro ao atualizar veículo: {str(e)}")
        return jsonify({'error': 'Erro ao atualizar veículo'}), 500

@app.route('/api/vehicles/<int:vehicle_id>', methods=['DELETE'])
@jwt_required()
def delete_vehicle(vehicle_id):
    try:
        user_id = get_jwt_identity()
        vehicle = Vehicle.query.filter_by(id=vehicle_id, user_id=user_id).first()
        
        if not vehicle:
            return jsonify({'error': 'Veículo não encontrado'}), 404
        
        db.session.delete(vehicle)
        db.session.commit()
        
        return jsonify({'message': 'Veículo excluído com sucesso'})
        
    except Exception as e:
        print(f"Erro ao excluir veículo: {str(e)}")
        return jsonify({'error': 'Erro ao excluir veículo'}), 500

# Rotas de Serviços
@app.route('/api/vehicles/<int:vehicle_id>/services', methods=['GET'])
@jwt_required()
def get_services(vehicle_id):
    try:
        user_id = get_jwt_identity()
        vehicle = Vehicle.query.filter_by(id=vehicle_id, user_id=user_id).first()
        
        if not vehicle:
            return jsonify({'error': 'Veículo não encontrado'}), 404
        
        services = Service.query.filter_by(vehicle_id=vehicle_id).order_by(Service.date.desc()).all()
        
        return jsonify([{
            'id': s.id,
            'service_type': s.service_type,
            'date': s.date.isoformat(),
            'mileage': s.mileage,
            'cost': s.cost,
            'notes': s.notes,
            'created_at': s.created_at.isoformat()
        } for s in services])
        
    except Exception as e:
        print(f"Erro ao buscar serviços: {str(e)}")
        return jsonify({'error': 'Erro ao buscar serviços'}), 500

@app.route('/api/vehicles/<int:vehicle_id>/services', methods=['POST'])
@jwt_required()
def create_service(vehicle_id):
    try:
        user_id = get_jwt_identity()
        vehicle = Vehicle.query.filter_by(id=vehicle_id, user_id=user_id).first()
        
        if not vehicle:
            return jsonify({'error': 'Veículo não encontrado'}), 404
        
        data = request.get_json()
        service = Service(
            vehicle_id=vehicle_id,
            service_type=data.get('service_type'),
            date=datetime.strptime(data.get('date'), '%Y-%m-%d').date(),
            mileage=data.get('mileage'),
            cost=data.get('cost', 0),
            notes=data.get('notes')
        )
        
        db.session.add(service)
        db.session.commit()
        
        return jsonify({
            'id': service.id,
            'service_type': service.service_type,
            'date': service.date.isoformat(),
            'mileage': service.mileage,
            'cost': service.cost,
            'notes': service.notes
        }), 201
        
    except Exception as e:
        print(f"Erro ao criar serviço: {str(e)}")
        return jsonify({'error': 'Erro ao criar serviço'}), 500

@app.route('/api/services/<int:service_id>', methods=['DELETE'])
@jwt_required()
def delete_service(service_id):
    try:
        user_id = get_jwt_identity()
        service = Service.query.join(Vehicle).filter(
            Service.id == service_id, 
            Vehicle.user_id == user_id
        ).first()
        
        if not service:
            return jsonify({'error': 'Serviço não encontrado'}), 404
        
        db.session.delete(service)
        db.session.commit()
        
        return jsonify({'message': 'Serviço excluído com sucesso'})
        
    except Exception as e:
        print(f"Erro ao excluir serviço: {str(e)}")
        return jsonify({'error': 'Erro ao excluir serviço'}), 500

# Rotas de Configuração de Manutenção
@app.route('/api/vehicles/<int:vehicle_id>/maintenance-config', methods=['GET'])
@jwt_required()
def get_maintenance_config(vehicle_id):
    try:
        user_id = get_jwt_identity()
        vehicle = Vehicle.query.filter_by(id=vehicle_id, user_id=user_id).first()
        
        if not vehicle:
            return jsonify({'error': 'Veículo não encontrado'}), 404
        
        configs = MaintenanceConfig.query.filter_by(vehicle_id=vehicle_id).all()
        
        return jsonify([{
            'id': c.id,
            'service_type': c.service_type,
            'interval_km': c.interval_km,
            'last_service_km': c.last_service_km
        } for c in configs])
        
    except Exception as e:
        print(f"Erro ao buscar configurações: {str(e)}")
        return jsonify({'error': 'Erro ao buscar configurações'}), 500

@app.route('/api/vehicles/<int:vehicle_id>/maintenance-config', methods=['POST'])
@jwt_required()
def update_maintenance_config(vehicle_id):
    try:
        user_id = get_jwt_identity()
        vehicle = Vehicle.query.filter_by(id=vehicle_id, user_id=user_id).first()
        
        if not vehicle:
            return jsonify({'error': 'Veículo não encontrado'}), 404
        
        data = request.get_json()
        
        # Remove existing configs
        MaintenanceConfig.query.filter_by(vehicle_id=vehicle_id).delete()
        
        # Add new configs
        for config in data.get('configs', []):
            maintenance_config = MaintenanceConfig(
                vehicle_id=vehicle_id,
                service_type=config.get('service_type'),
                interval_km=config.get('interval_km'),
                last_service_km=config.get('last_service_km', 0)
            )
            db.session.add(maintenance_config)
        
        db.session.commit()
        
        return jsonify({'message': 'Configurações salvas com sucesso'})
        
    except Exception as e:
        print(f"Erro ao salvar configurações: {str(e)}")
        return jsonify({'error': 'Erro ao salvar configurações'}), 500

# Rotas de Estatísticas
@app.route('/api/vehicles/<int:vehicle_id>/stats', methods=['GET'])
@jwt_required()
def get_vehicle_stats(vehicle_id):
    try:
        user_id = get_jwt_identity()
        vehicle = Vehicle.query.filter_by(id=vehicle_id, user_id=user_id).first()
        
        if not vehicle:
            return jsonify({'error': 'Veículo não encontrado'}), 404
        
        services = Service.query.filter_by(vehicle_id=vehicle_id).all()
        
        total_services = len(services)
        total_cost = sum(s.cost for s in services)
        
        # Calculate cost by category
        cost_by_category = {}
        for service in services:
            if service.service_type in cost_by_category:
                cost_by_category[service.service_type] += service.cost
            else:
                cost_by_category[service.service_type] = service.cost
        
        # Calculate monthly average (last 6 months)
        six_months_ago = datetime.now() - timedelta(days=180)
        
        recent_services = [s for s in services if s.date >= six_months_ago.date()]
        monthly_cost = sum(s.cost for s in recent_services) / 6 if recent_services else 0
        
        # Next maintenance calculation
        maintenance_configs = MaintenanceConfig.query.filter_by(vehicle_id=vehicle_id).all()
        next_maintenance = 0
        
        for config in maintenance_configs:
            if config.interval_km > 0:
                last_service = max([s.mileage for s in services if s.service_type == config.service_type] or [0])
                next_km = last_service + config.interval_km
                remaining = next_km - vehicle.current_mileage
                if remaining > 0 and (next_maintenance == 0 or remaining < next_maintenance):
                    next_maintenance = remaining
        
        return jsonify({
            'total_services': total_services,
            'total_cost': total_cost,
            'cost_by_category': cost_by_category,
            'monthly_average': monthly_cost,
            'current_mileage': vehicle.current_mileage,
            'next_maintenance': next_maintenance
        })
        
    except Exception as e:
        print(f"Erro ao buscar estatísticas: {str(e)}")
        return jsonify({'error': 'Erro ao buscar estatísticas'}), 500

# Rota de teste
@app.route('/')
def hello():
    return '🚀 MotoManutenção API está rodando!'

@app.route('/api/test')
def test():
    return {'message': 'API funcionando!', 'timestamp': datetime.now().isoformat()}

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        
        # Criar usuário de teste se não existir
        if not User.query.filter_by(email='motoboy@exemplo.com').first():
            test_user = User(name='Motoboy Teste', email='motoboy@exemplo.com')
            test_user.set_password('123456')
            db.session.add(test_user)
            db.session.commit()
            print("👤 Usuário de teste criado: motoboy@exemplo.com / 123456")
    
    print("🚀 Servidor Flask iniciando...")
    print("📊 Banco de dados: SQLite")
    print("🔗 API disponível em: http://localhost:5000")
    print("👤 Usuário teste: motoboy@exemplo.com / 123456")
    print("⏹️  Pressione Ctrl+C para parar o servidor")
    app.run(debug=True, port=5000)